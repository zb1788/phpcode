### 0.4.0(150927)

* 增加参数scrollArea
* 修复未滑动到底部就加载bug

### 0.3.0(150410)

* 增加`lock()` 和`unlock()` API
* 修复拉动加载时还可拉动bug

### 0.2.0(150325)

* 修改参数domUp、domDown，增加参数loadUpFn、loadDownFn，删除参数direction

### 0.1.0(141024)

* 支持上/下拉
* 支持自定义拉动的DOM